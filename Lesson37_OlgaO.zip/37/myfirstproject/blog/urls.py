from django.urls import path
from . import views
from django.conf.urls import handler404, handler500
# from myapp import views

from django.shortcuts import get_object_or_404, render
from .models import MyModel

def my_view(request) :
    obj = get_object_or_404(MyModel, pk=l)
    return render(request, 'my_template.html', {'object': obj})

# handler404 = views.my_custom_404_view
# handler500 = views.my_custom_error_view
urlpatterns = [

    path('', views.home, name='blog-home'),
    path('about/', views.about, name='about-club'),

    path('postuser/', views.postuser),
    path('greet/<str:name>/', views.greet, name='greet'), 

]