# В отдельном файле user_manager.py

from sqlalchemy.orm import sessionmaker
from models import User, engine

class UserManager:
    def __init__(self):
        self.Session = sessionmaker(bind=engine)

    def create_user(self, username, password):
        session = self.Session()
        user = User(username=username, password=password)
        session.add(user)
        session.commit()
        session.close()

    def authenticate_user(self, username, password):
        session = self.Session()
        user = session.query(User).filter_by(username=username, password=password).first()
        session.close()
        return user
