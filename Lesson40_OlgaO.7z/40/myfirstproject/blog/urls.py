from django.urls import path
from . import views
from django.conf.urls import handler404, handler500
# from myapp import views

from django.shortcuts import get_object_or_404, render


# handler404 = views.my_custom_404_view
# handler500 = views.my_custom_error_view
urlpatterns = [ 

    path('', views.home, name='blog-home'),
    path('about/', views.about, name='about-club'),

    path('postuser/', views.postuser),
    path('greet/<str:name>/', views.greet, name='greet'), 
    path('books/', views.show_books, name='show_books'),
    # path('books/<slug:slug>/', BookDetailView.as_view(), name='book-detail'),
]