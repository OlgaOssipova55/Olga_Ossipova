# Класс администратора для модели Author (если он используется)


from django.contrib import admin
from .models import Book,Author

from django.utils.translation import gettext_lazy as _
# Класс администратора для модели Book
@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'published_year')
    list_filter = ('published_year', 'author')
    search_fields = ['title', 'author＿name']
    # Пользовательский фильтр для модели Author (если он используется)
class DecadeBornListFilter(admin.SimpleListFilter):
    title = _('decade born')
    parameter_name = 'decade'
    def lookups(self, request, model_admin):
        return (
        ('1950s', _('Born in the 1950s')),
        ('1960s', _('Born in the 1960s')),
        )
    def queryset(self, request, queryset):
        if self.value() == '1950s':
            return queryset.filter(born＿gte=1950, born＿lt=1960)
        if self.value() == '1960s':
            return queryset.filter(born＿gte=1960, born＿lt=1970)
        # Класс администратора для модели Book
@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    search_fields = ['title', 'author__name']  # Assuming the Author model has a 'name' field


admin.site. register(Book)
# Register your models here.

class BookAdmin(admin. ModelAdmin):
    list_display = ('title', 'author', 'published_year')
    # Поля, отображаемые в списке
    list_filter = ('author', 'published_year')
    # Фильтры сбоку
    search_fields = ('title', 'author＿name')
    # Поля поиска
    # Затем зарегистрируйте модель с этим классом
admin.site.register(Book, BookAdmin)


