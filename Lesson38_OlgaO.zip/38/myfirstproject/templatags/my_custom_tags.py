from django import template


register = template. Library()
@register. simple_tag
@register.inclusion_tag ('my_template.html')

def my_inclusion_tag(some_list):
    return {'some list': some_list}

def my_simple_tag(a, b):
    return a + b