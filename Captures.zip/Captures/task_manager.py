import sqlite3
from sqlite3 import Error

class Task:
    def __init__(self, name, deadline, description):
        self.name = name
        self.deadline = deadline
        self.description = description

    def __str__(self):
        return f"Задача: {self.name}   Срок: {self.deadline}\n   Описание: {self.description}"

class TaskManager:
    def __init__(self, db_file=":memory:"):
        self.db_file = db_file
        self.tasks = []
        self.load_tasks_from_db()

    def add_task(self, name, deadline, description):
        new_task = Task(name, deadline, description)
        self.tasks.append(new_task)

    def show_tasks(self):
        return '\n'.join(str(task) for task in self.tasks)

    def delete_task(self, index):
        if 0 <= index < len(self.tasks):
            del self.tasks[index]

    def update_task(self, index, name, deadline, description):
        if 0 <= index < len(self.tasks):
            if name:
                self.tasks[index].name = name
            if deadline:
                self.tasks[index].deadline = deadline
            if description:
                self.tasks[index].description = description
            return True
        return False

    def load_tasks_from_db(self):
        try:
            connection = sqlite3.connect(self.db_file)
            cursor = connection.cursor()
            cursor.execute("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, name TEXT, deadline TEXT, description TEXT)")
            connection.commit()

            cursor.execute("SELECT * FROM tasks")
            rows = cursor.fetchall()
            for row in rows:
                task = Task(row[1], row[2], row[3])
                self.tasks.append(task)

        except Error as e:
            print(e)

        finally:
            if connection:
                connection.close()

    def save_tasks_to_db(self):
        try:
            connection = sqlite3.connect(self.db_file)
            cursor = connection.cursor()
            cursor.execute("DROP TABLE IF EXISTS tasks")
            cursor.execute("CREATE TABLE tasks (id INTEGER PRIMARY KEY, name TEXT, deadline TEXT, description TEXT)")

            for task in self.tasks:
                cursor.execute("INSERT INTO tasks (name, deadline, description) VALUES (?, ?, ?)",
                               (task.name, task.deadline, task.description))

            connection.commit()

        except Error as e:
            print(e)

        finally:
            if connection:
                connection.close()
        
    def get_task(self, index):
        if 0 <= index < len(self.tasks):
            return self.tasks[index]
        return None  # или поднимать исключение, или обрабатывать этот случай как-то иначе
    

    def update_task(self, index, name, deadline, description):
        if 0 <= index < len(self.tasks):
            self.tasks[index].name = name
            self.tasks[index].deadline = deadline
            self.tasks[index].description = description
            return True
        else:
            return False


