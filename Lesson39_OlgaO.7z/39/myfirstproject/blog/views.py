from django.shortcuts import render
from django.http import HttpResponse
from django.http import Http404
from django.shortcuts import render,redirect


def greet(request,name):
    return HttpResponse(f'Привет, {name}!')
def home(request):
    return HttpResponse('<h1>Главная</h1>')
def about (request):
    return HttpResponse('<hl>Вторая страница</hl>')
def get_example (request):
    name = request.GET.get('name', 'Гость')
    return HttpResponse(f"Привет, {name}!")

def index(request) :
    return render(request, "home.html")

def postuser(request):
    name = request.POST.get("name", "Undefined")
    age = request.POST.get("age", 1)
    return HttpResponse(f"<h2>Name: {name} Age: {age}</h2>")

def go_home(request):
    return redirect("home")
def home_view(request):
    context ={'title': 'Главная страница',
    'description': 'Это описание главной страницы.'
    }
    return render(request, 'home.html', context)
def products_view(request):
    products= [
    {'name': 'Продукт 1', 'price': 150},
    {'name': 'Продукт 2', 'price': 300},
    {'name': 'Продукт 3', 'price': 450} 
    ]
    return render(request, 'products.html', {'products': products})