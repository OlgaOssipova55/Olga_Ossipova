from django import template
from django.shortcuts import render


register = template. Library()
@register.filter(name='capitalize')

def capitalize(value):
    """ Преобразует первую букву каждого слова в верхний регистр """
    return value.title()

def Text (request):
    context ={ 'my text': 'The kindness is brilliant of heart, Its higherthan mountains around.',
    }
    return render(request, 'text.html', context)